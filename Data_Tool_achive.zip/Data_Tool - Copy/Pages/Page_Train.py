import subprocess,os
import streamlit as st
from Data_Tool.Utilities.Data_meta import Data_meta

def Page_Train():
    st.title("Train Model")
    data_meta = Data_meta.get_instance()
    data_meta.save_to_json('data_meta.json')
    
    # 设置工作目录到项目的根目录
    root_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
    os.chdir(root_dir)
    
    if st.button('Start Training'):
        command = ['train3dunet', '--config', 'resources/3DUnet_multiclass/train_config.yaml']
        cmd = 'start cmd /c ' + ' '.join(command)
        result = subprocess.Popen(cmd, shell=True)
        st.text("Training started in a new command window...")

