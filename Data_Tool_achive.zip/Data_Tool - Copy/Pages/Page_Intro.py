import streamlit as st

def Page_Intro():
    st.title("How to use this toolset")
    st.write("Use data handler to prepare training data")
    st.write("Then use traing tools to train")